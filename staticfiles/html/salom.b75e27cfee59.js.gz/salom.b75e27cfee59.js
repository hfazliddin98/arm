var flavor = "vanila";
var vessel = "cone";
var toppings = "sprinkles";

// Add your code here
if (flavor==='vanila'){
    if (vessel==='cone'){
        if (toppings==='sprinkles'){
            console.log('I\'d like two scoops of '+ flavor +' ice cream in a '+ vessel +' with '+ toppings +'.');
        }
    }
    
}
if (flavor==='vanila'){
    if (vessel==='cone'){
        if (toppings==='peanuts'){
            console.log('I\'d like two scoops of '+ flavor +' ice cream in a '+ vessel +' with '+ toppings +'.');
        }
    }
    
}
if (flavor==='vanila'){
    if (vessel==='bowl'){
        if (toppings==='sprinkles'){
            console.log('I\'d like two scoops of '+ flavor +' ice cream in a '+ vessel +' with '+ toppings +'.');
        }
    }
    
}
if (flavor==='vanila'){
    if (vessel==='bowl'){
        if (toppings==='peanuts') {
            console.log('I\'d like two scoops of '+ flavor +' ice cream in a '+ vessel +' with '+ toppings +'.');
        }
    }
    
}
if (flavor==='chocolate'){
    if (vessel==='cone'){
        if (toppings==='sprinkles'){
            console.log('I\'d like two scoops of '+ flavor +' ice cream in a '+ vessel +' with '+ toppings +'.');
        }
    }
    
}
if (flavor==='chocolate'){
    if (vessel==='cone'){
        if (toppings==='peanuts'){
            console.log('I\'d like two scoops of '+ flavor +' ice cream in a '+ vessel +' with '+ toppings +'.');
        }
    }
    
}
if (flavor==='chocolate'){
    if (vessel==='bowl'){
        if (toppings==='sprinkles') {
            console.log('I\'d like two scoops of '+ flavor +' ice cream in a '+ vessel +' with '+ toppings +'.');
        }
    }
    
}
if (flavor==='chocolate'){
    if (vessel==='bowl'){
        if (toppings==='peanuts') {
            console.log('I\'d like two scoops of '+ flavor +' ice cream in a '+ vessel +' with '+ toppings +'.');
        }
    }
    
}
else {
    console.log('hatolik bor');
}
    